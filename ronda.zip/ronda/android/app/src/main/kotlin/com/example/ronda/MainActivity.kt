package com.example.ronda

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
