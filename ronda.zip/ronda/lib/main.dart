import 'package:ronda/app/views/home/bottom_menu.dart';
import 'package:flutter/material.dart';

import 'app/views/home/login.dart';

void main() {
  runApp(const ApWidget());
}

class ApWidget extends StatelessWidget {
  const ApWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
          scaffoldBackgroundColor: Color.fromARGB(255, 246, 247, 245)),
      home: const Login(),
    );
  }
}
